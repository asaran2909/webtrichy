// Loads an image for every element with data-q from Wikipedia/Wikimedia (needs internet).
document.querySelectorAll('[data-q]').forEach(async el=>{
  try{
    const u='https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrlimit=1&prop=pageimages&piprop=thumbnail&pithumbsize=700&format=json&origin=*&gsrsearch='+encodeURIComponent(el.dataset.q);
    const j=await (await fetch(u)).json();
    const p=Object.values(j.query.pages)[0];
    if(p&&p.thumbnail){const i=new Image();i.alt=el.dataset.q;i.src=p.thumbnail.source;i.onload=()=>{el.replaceWith(i)}}
  }catch(e){}
});
// Reviews saved in this browser only (localStorage). For public reviews use a backend/database.
const form=document.getElementById('rf');
if(form){
  const list=document.getElementById('rl');
  const load=()=>{try{return JSON.parse(localStorage.getItem('trichyReviews')||'[]')}catch(e){return[]}};
  const show=()=>{list.innerHTML='';load().reverse().forEach(r=>{const d=document.createElement('div');d.className='rv';
    d.innerHTML='<b></b> '+'\u2605'.repeat(r.s)+'<br><span></span>';d.querySelector('b').textContent=r.n;d.querySelector('span').textContent=r.t;list.appendChild(d)})};
  form.onsubmit=e=>{e.preventDefault();const a=load();a.push({n:form.n.value.trim(),s:+form.s.value,t:form.t.value.trim()});
    try{localStorage.setItem('trichyReviews',JSON.stringify(a))}catch(e){}form.reset();show()};
  show();
}
